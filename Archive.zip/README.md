# encuesta-intermed-mx
Encuesta para estadística interna
