</div>
  </div>

    <!-- Aqui termina el body de la pagina -->
    <script src="<?echo base_url(); ?>js/jquery.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <script src="<?echo base_url(); ?>js/bootstrap.min.js"></script>
    <script src="<?echo base_url(); ?>js/Chart.js"></script>
    <script src="<?echo base_url(); ?>js/utils.js"></script>
  </body>
</html>
<!--<footer class="navbar-fixed-bottom footerAdmin">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <img class="footer-logoAdmin pull-right" src="<?echo base_url();?>img/logos/intermedSimple.png">
        <p class="footer-legal flamaBook-normal s15 pull-right text-right">
          Todos los Derechos Reservados &copy; 2015 <span class="Flama-normal s20 ls-1">intermed<sup>&reg;</sup></span><br>
          New Channel Media. Guadalajara, Jalisco. Mex.
        </p>
      </div>
    </div>
  </div>
</footer>-->
