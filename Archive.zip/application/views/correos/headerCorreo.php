<!DOCTYPE html>
<html>
  <head>
    <title><?php echo $titulo; ?></title>
  </head>
  <body>
    <!-- Arranca el boty papa -->
