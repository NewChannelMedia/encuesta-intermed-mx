<!-- carga de datos dinamicamente xD -->
<table border = "1">
  <tbody>
    <tr>
      <td>Dato aleatorio numero uno</td>
    </tr>
    <tr>
      <td>Dato aleatorio numero dos</td>
    </tr>
    <tr>
      <td>
        <div class = "" id = "codigo">
          <span>Este es tu código de acceso al sistema: <h2 id = "codigo"></h2></span>
          <span><p>con el Cual puedes entrar en la siguiente liga</p></span>
          <a href = "http://www.newchannel.mx/encuesta-intermed">Usar mi código</a>
        </div>
      </td>
    </tr>
    <tr>
      <td>
        <div class = "" id = "mensaje">
          <span>
              <p id ="mes"></p>
          </span>
        </div>
      </td>
    </tr>
  </tbody>
</table>
