<a href = "<?php  base_url()  ?>codigo/pedir" class = "">Solicitar correo</a>
